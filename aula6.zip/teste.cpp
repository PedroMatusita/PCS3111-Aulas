#include "Pedido.h"
#include "Produto.h"
#include "Combo.h"

void teste1() {
    Produto *p1 = new Produto("Pipoca Grande",20);
    Produto *p2 = new Produto("Coca-Cola 1L",15);

    Produto* p[2];
    p[0] = p1;
    p[1] = p2;


    Combo *c1 = new Combo("Combo 2",p,2,0.2);
    c1 ->imprimir();
    delete c1;
    delete p1;
    delete p2;
}

void teste2() {
    Produto *p1 = new Produto("Pipoca Grande",20);
    Produto *p2 = new Produto("Coca-Cola 1L",15);

    Produto* p[2];
    p[0] = p1;
    p[1] = p2;


    Combo *c1 = new Combo("Combo 2",p,2,0.2);

    Produto *p3 = new Produto("Pipoca Pequena",15);
    Produto *p4 = new Produto("Pepsi 500ml",10);

    Pedido *ped1 = new Pedido(3);
    ped1->adicionar(c1);
    ped1->adicionar(p3);
    ped1->adicionar(p4);

    ped1->imprimir();

    ped1->remover(p3);
    ped1->imprimir();

    delete ped1;
    delete c1;
    delete p1;
    delete p2;
    delete p3;
    delete p4;
}

