#include "Combo.h"

#include <iostream>

using namespace std;


Combo::Combo(string nome, Produto **p, int quantidadeDeProdutos, double desconto) :Produto (nome,0){
    this -> nome = nome;
    this ->  quantidadeDeProdutos = getQuantidadeDeProdutos();
    this -> desconto = desconto;

    double precoTotal = 0;
    for(int i = 0; i < quantidadeDeProdutos; i++)
        precoTotal += p[i]->getPreco();

    this-> preco = precoTotal*(1-desconto);
}

Combo::~Combo(){
}

Produto ** Combo::getProdutos(){
    return p;
}

int Combo::getQuantidadeDeProdutos(){
    return quantidadeDeProdutos;
}

double Combo::getDesconto(){
    return desconto;
}