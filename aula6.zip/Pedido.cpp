//Faca os includes necessarios
//Implemente aqui os metodos
#include "Pedido.h"

Pedido::Pedido(int quantidadeMaxima) {
    this->quantidadeMaxima = quantidadeMaxima;
    produtos = new Produto*[quantidadeMaxima];
    this->quantidade = 0;
}

Pedido::~Pedido() {
    // implemente
    delete[] produtos;
    }

bool Pedido::adicionar(Produto *p) {
    if (quantidade >= quantidadeMaxima) {
        return false;
    }

    // Verificar se o produto já está na lista
    for (int i = 0; i < quantidade; i++) {
        if (produtos[i] == p) {
            return false;
        }
    }

    produtos[quantidade] = p;
    quantidade++;
    return true;
}


bool Pedido::remover(Produto *p) {
    for (int i = 0; i < quantidade; i++) {
        if (produtos[i] == p) {
            
            for (int j = i; j < quantidade - 1; j++) {
                produtos[j] = produtos[j + 1]; 
            }
            quantidade--; 
            return true; 
        }
    }


    return false;
}


Produto** Pedido::getProdutos() {
    return produtos;
}

int Pedido::getQuantidadeDeProdutos() {
    return quantidade;
}

double Pedido::getValor() {
    double precoTotal = 0;
    for(int i = 0; i < getQuantidadeDeProdutos(); i++)
        precoTotal += getProdutos()[i]->getPreco();

    return precoTotal;
}

void Pedido::imprimir() {
    cout << "Pedido com " << getQuantidadeDeProdutos() << " produto(s) - " << getValor() << " reais" << endl;
    for (int i = 0; i < getQuantidadeDeProdutos(); i++)
        getProdutos()[i]->imprimir();
    cout << endl;
}