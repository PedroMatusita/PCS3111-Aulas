//Faca os includes necessarios
#include "Pedido.h"
#include "Produto.h"
#include "ProdutoComDesconto.h"
#include "Item.h"
#include <string>
#include <iostream>

using namespace std;

void teste1(){
    //Implemente o teste1
    Pedido* ped1 = new Pedido(2);

    Produto* p1 = new Produto("Bala de Goma",3.5);
    ped1 -> adicionar(p1);

    Produto* p2 = new Produto("Chocolate",5.2);
    ped1 -> adicionar(p2,4);

    ped1 -> imprimir();

    delete ped1;
    delete p1;
    delete p2;
}

void teste2(){
    //Implemente o teste2
    Pedido* ped1 = new Pedido(2);

    Produto* p1 = new Produto("Linguica",20.9);
    ped1 -> adicionar(p1,2);

    Produto* p2 = new ProdutoComDesconto("Picanha",70.49,0.1);
    ped1 -> adicionar(p2);

    ped1 -> imprimir();

    delete ped1;
    delete p1;
    delete p2;
}

// void teste3() {
//     //Implemente o teste3
//     int quantidade;
//     Pedido* ped1 = new Pedido(2);

//     ProdutoComDesconto** produtosComDesconto = ped1->getProdutosComDesconto(quantidade);

//     ped1 -> getProdutosComDesconto(quantidade);
//     cout << quantidade << endl;

//     Produto* p1 = new Produto("Refrigerante",7.8);
//     ped1 -> adicionar(p1,2);

//     ped1 -> getProdutosComDesconto(quantidade);
//     cout << quantidade << endl;

//     Produto* p2 = new ProdutoComDesconto("Pizza",40.99,0.1);
//     ped1 -> adicionar(p2,2);

//     ped1 -> getProdutosComDesconto(quantidade);
//     cout << quantidade << endl;

//     delete ped1;
//     delete p1;
//     delete p2;
// }

void teste3() {
    Pedido* pedido = new Pedido(2);

    int quantidadeComDesconto;
    ProdutoComDesconto** produtosComDesconto = pedido->getProdutosComDesconto(quantidadeComDesconto);

    cout << quantidadeComDesconto << endl << endl;

    Produto* refrigerante = new Produto("Refrigerante", 7.80);
    pedido -> adicionar(refrigerante, 2);

    produtosComDesconto = pedido->getProdutosComDesconto(quantidadeComDesconto);
    cout << quantidadeComDesconto << endl << endl;


    ProdutoComDesconto* pizza = new ProdutoComDesconto("Pizza", 40.99, 0.1);
    pedido->adicionar(pizza, 2);

    produtosComDesconto = pedido->getProdutosComDesconto(quantidadeComDesconto);
    cout << quantidadeComDesconto << endl << endl;

    delete pedido;
    delete refrigerante;
    delete pizza;
}


