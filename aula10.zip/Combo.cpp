#include "Combo.h"
#include <stdexcept>
#include <iostream>

using namespace std;

Combo::Combo(string nome) : Produto(nome, 0)  {
    prods = new vector <Produto*>();
}

Combo::~Combo() {
    delete prods;
}

void Combo::adicionar(Produto *p) {

    for (int i = 0; i < prods->size(); i++)
        if ((*prods)[i] == p) throw new invalid_argument("Produto ja existe");
    prods-> push_back(p);
}

double Combo::getPreco() {
    double soma = 0;
    for (int i = 0; i < prods->size(); i++)
        soma += (*prods)[i]->getPreco();
    return soma;
}

void Combo::imprimir() {
    cout << nome << " - " << getPreco() << " reais cada" << endl;
    for (int i = 0; i < prods->size(); i++)
        (*prods)[i]->imprimir();
}


vector <Produto*>* Combo::getProdutos() {
    return prods;
}