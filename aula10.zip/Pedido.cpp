#include "Pedido.h"

#include <iostream>
#include <stdexcept>

using namespace std;

Pedido::Pedido() : quantidade(0) {
    itens = new list<Item*>();
}

Pedido::~Pedido() {
    cout << "Pedido com " << quantidade << " item(ns) destruido" << endl;
    for (auto it = itens->begin(); it != itens->end(); ++it) delete *it;
    delete itens;
}

void Pedido::adicionar(Produto* produto, int quantidade) {
    for (auto it = itens->begin(); it != itens->end(); ++it)
        if (produto == (*it)->getProduto()) throw new invalid_argument("Produto ja existente");

    itens->push_back(new Item(produto, quantidade));
    this->quantidade += quantidade;
}

void Pedido::imprimir() {
    cout << "Pedido - " << quantidade << " item(ns)" << endl;
    for (auto it = itens->begin(); it != itens->end(); ++it) (*it)->imprimir();
}