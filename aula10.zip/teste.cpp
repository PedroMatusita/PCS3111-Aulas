//Faca os includes necessarios
#include "Combo.h"
#include "Item.h"
#include "Produto.h"
#include "Pedido.h"

using namespace std;

void teste1() {
    //Implemente segundo o enunciado
    Combo* c1 = new Combo("Burger e bebida");

    Produto* p1 = new Produto("X-Bacon",24.99);

    c1->adicionar(p1);

    Produto* p2 = new Produto("Coca-Cola Lata", 4.49);

    c1->adicionar(p2);

    c1->imprimir();

    delete c1;
    delete p2;
    delete p1;
}

void teste2() {
    //Implemente segundo o enunciado
    Pedido* ped = new Pedido();

    Combo* c1 = new Combo("Burger e bebida");

    Produto* p1 = new Produto("X-Bacon",24.99);

    c1->adicionar(p1);

    Produto* p2 = new Produto("Coca-Cola Lata", 4.49);

    c1->adicionar(p2);

    ped->adicionar(c1,2);

    Produto* p3 = new Produto("Sundae", 7.85);

    ped->adicionar(p3,2);

    ped->imprimir();

    delete ped;
    delete c1;
    delete p2;
    delete p1;
    delete p3;

}