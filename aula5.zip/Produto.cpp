#include "Produto.h"

#include <iostream>

using namespace std;

// IMPLEMENTAR CONSTRUTOR

string Produto::getNome() {
    return nome;
}

double Produto::getPreco() {
    return preco;
}

void Produto::imprimir(){
    cout << nome << " - " << preco << " reais cada" << endl;
}

Produto::Produto(string nome, double preco){
    this -> nome = nome;
    this -> preco = preco;
}

Produto::~Produto(){
    cout << "Produto " << nome << " destruido" << endl;
}