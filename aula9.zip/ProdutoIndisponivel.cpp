#include "Item.h"
#include "Pedido.h"
#include "Produto.h"
#include "ProdutoIndisponivel.h"

#include <iostream>
#include <stdexcept>

ProdutoIndisponivel::ProdutoIndisponivel(string message) : logic_error(message){

}

ProdutoIndisponivel::~ProdutoIndisponivel(){
    
}