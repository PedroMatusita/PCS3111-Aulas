#include "Item.h"
#include "Pedido.h"
#include "Produto.h"

#include <iostream>
#include <stdexcept>

using namespace std;

class ProdutoIndisponivel : public logic_error {
public:
    ProdutoIndisponivel(string message);
    virtual ~ProdutoIndisponivel();
};