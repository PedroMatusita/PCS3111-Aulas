//Faca os includes necessarios
#include "Item.h"
#include "Pedido.h"
#include "Produto.h"
#include "ProdutoIndisponivel.h"

#include <iostream>
#include <stdexcept>

using namespace std;

void teste1(){
    /*Implemente conforme o enunciado*/
    // try {
    //     cout << "teste" << endl;
    //     Produto p1("Nome", -1);
    // } catch (invalid_argument* e) {
    //     cout << "Erro: " << e->what() << endl;
    //     delete e;
    // }

    try {
        Produto p1("Nome", -1);
    } catch (const invalid_argument& e) {
        cout << "Erro: " << e.what() << endl;
    }

}

void teste2(){
    /*Implemente conforme o enunciado*/

try {
    Produto* p1 = new Produto("Gatorade", 7.5);
    cout << p1->getPreco() << endl;
    p1->setDisponivel(false);
    p1->getPreco(); 
} catch (const exception& e) {
    cout << "Erro: " << e.what() << endl;
}

}

void teste3(){
    /*Implemente conforme o enunciado*/ 
    Pedido* ped1 = new Pedido(4);
    Produto* p1 = new Produto("Cerveja",4.35);
    Produto* p2 = new Produto("Bis",3.90);
    Produto* p3 = new Produto("Frigideira",80.79);
    Produto* p4 = new Produto("Vassoura",30.50);

    ped1->adicionar(p1,5);
    ped1->adicionar(p2,2);
    ped1->adicionar(p3,1);
    ped1->adicionar(p4,1);

    cout << ped1->calcularPrecoTotal() << endl;
    p1->setDisponivel(false);
    p3->setDisponivel(false);

    cout << ped1->calcularPrecoTotal() << endl;
    p2->setDisponivel(false);
    p4->setDisponivel(false);

    cout << ped1->calcularPrecoTotal() << endl;

}
