//Faca os includes necessarios

#include "Produto.h"
#include "ProdutoIndisponivel.h"

#include <iostream>

using namespace std;

#include <stdexcept> 

Produto::Produto(string nome, double preco) : nome(nome), preco(preco), disponivel(true) {
    if (preco < 0) {
        throw invalid_argument("Preco invalido");
    }
}

Produto::~Produto() {
    cout << "Produto " << nome << " destruido" << endl;
}

string Produto::getNome() {
    return nome;
}

double Produto::getPreco() {
    if (!disponivel) {
        throw ProdutoIndisponivel("Produto Indisponivel");
    }
    // Altere conforme o enunciado
    return preco;
}

bool Produto::getDisponivel() {
    return disponivel;
}

void Produto::setDisponivel(bool disponivel) {
    this->disponivel = disponivel;
}

void Produto::imprimir(){
    cout << nome << " - " << getPreco() << " reais cada" << endl;
}
